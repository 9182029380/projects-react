export interface InvoiceData {
  // Company Details
  companyName: string;
  companyAddress: string;
  companyEmail: string;
  companyPhone: string;
  panNumber: string;
  gstNumber: string;
  
  // Bank Details
  bankName: string;
  bankAddress: string;
  accountNumber: string;
  ifscCode: string;
  
  // Trainer Details
  trainerName: string;
  trainerEmail: string;
  trainerPhone: string;
  
  // Client Details
  clientName: string;
  clientAddress: string;
  clientEmail: string;
  clientPhone: string;
  
  // Billing Details
  invoiceNumber: string;
  billingType: 'hourly' | 'daily' | 'monthly';
  rate: number;
  units: number;
  startDate: string;
  endDate: string;
}