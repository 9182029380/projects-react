import React, { useState } from 'react';
import { Calendar, Clock, DollarSign, Building2, User, Users } from 'lucide-react';
import { InvoiceData } from '../types/invoice';
import { generateInvoiceNumber } from '../utils/generateInvoiceNumber';
import InvoicePreview from './InvoicePreview';

const initialInvoiceData: InvoiceData = {
  companyName: '',
  companyAddress: '',
  companyEmail: '',
  companyPhone: '',
  panNumber: '',
  gstNumber: '',
  bankName: '',
  bankAddress: '',
  accountNumber: '',
  ifscCode: '',
  trainerName: '',
  trainerEmail: '',
  trainerPhone: '',
  clientName: '',
  clientAddress: '',
  clientEmail: '',
  clientPhone: '',
  invoiceNumber: generateInvoiceNumber(),
  billingType: 'hourly',
  rate: 0,
  units: 0,
  startDate: '',
  endDate: '',
};

export default function InvoiceForm() {
  const [invoiceData, setInvoiceData] = useState<InvoiceData>(initialInvoiceData);
  const [showPreview, setShowPreview] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInvoiceData(prev => ({ ...prev, [name]: value }));
  };

  const generatePDF = () => {
    const invoiceContent = document.getElementById('invoice-preview');
    if (invoiceContent) {
      window.print();
    }
  };

  if (showPreview) {
    return (
      <InvoicePreview
        data={invoiceData}
        onBack={() => setShowPreview(false)}
        onDownload={generatePDF}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="space-y-6 bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Training Invoice Generator</h2>
        
        {/* Company Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Company Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="companyName"
              placeholder="Company Name"
              className="input-field"
              value={invoiceData.companyName}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="companyAddress"
              placeholder="Company Address"
              className="input-field"
              value={invoiceData.companyAddress}
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="companyEmail"
              placeholder="Company Email"
              className="input-field"
              value={invoiceData.companyEmail}
              onChange={handleInputChange}
            />
            <input
              type="tel"
              name="companyPhone"
              placeholder="Company Phone"
              className="input-field"
              value={invoiceData.companyPhone}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="panNumber"
              placeholder="PAN Number"
              className="input-field"
              value={invoiceData.panNumber}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="gstNumber"
              placeholder="GST Number"
              className="input-field"
              value={invoiceData.gstNumber}
              onChange={handleInputChange}
            />
          </div>
        </div>

        {/* Bank Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Bank Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="bankName"
              placeholder="Bank Name"
              className="input-field"
              value={invoiceData.bankName}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="bankAddress"
              placeholder="Bank Address"
              className="input-field"
              value={invoiceData.bankAddress}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="accountNumber"
              placeholder="Account Number"
              className="input-field"
              value={invoiceData.accountNumber}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="ifscCode"
              placeholder="IFSC Code"
              className="input-field"
              value={invoiceData.ifscCode}
              onChange={handleInputChange}
            />
          </div>
        </div>

        {/* Client Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Users className="w-5 h-5" />
            Client Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="clientName"
              placeholder="Client Name"
              className="input-field"
              value={invoiceData.clientName}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="clientAddress"
              placeholder="Client Address"
              className="input-field"
              value={invoiceData.clientAddress}
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="clientEmail"
              placeholder="Client Email"
              className="input-field"
              value={invoiceData.clientEmail}
              onChange={handleInputChange}
            />
            <input
              type="tel"
              name="clientPhone"
              placeholder="Client Phone"
              className="input-field"
              value={invoiceData.clientPhone}
              onChange={handleInputChange}
            />
          </div>
        </div>

        {/* Trainer Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <User className="w-5 h-5" />
            Trainer Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="trainerName"
              placeholder="Trainer Name"
              className="input-field"
              value={invoiceData.trainerName}
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="trainerEmail"
              placeholder="Trainer Email"
              className="input-field"
              value={invoiceData.trainerEmail}
              onChange={handleInputChange}
            />
            <input
              type="tel"
              name="trainerPhone"
              placeholder="Trainer Phone"
              className="input-field"
              value={invoiceData.trainerPhone}
              onChange={handleInputChange}
            />
          </div>
        </div>

        {/* Billing Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Billing Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <select
              name="billingType"
              className="input-field"
              value={invoiceData.billingType}
              onChange={handleInputChange}
            >
              <option value="hourly">Hourly</option>
              <option value="daily">Daily</option>
              <option value="monthly">Monthly</option>
            </select>
            <input
              type="number"
              name="rate"
              placeholder="Rate"
              className="input-field"
              value={invoiceData.rate}
              onChange={handleInputChange}
            />
            <input
              type="number"
              name="units"
              placeholder="Number of Units"
              className="input-field"
              value={invoiceData.units}
              onChange={handleInputChange}
            />
            <input
              type="date"
              name="startDate"
              className="input-field"
              value={invoiceData.startDate}
              onChange={handleInputChange}
            />
            <input
              type="date"
              name="endDate"
              className="input-field"
              value={invoiceData.endDate}
              onChange={handleInputChange}
            />
          </div>
        </div>

        <button
          onClick={() => setShowPreview(true)}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Preview Invoice
        </button>
      </div>
    </div>
  );
}