import React from 'react';
import { Download } from 'lucide-react';
import { InvoiceData } from '../types/invoice';
import { numberToWords } from '../utils/numberToWords';

interface InvoicePreviewProps {
  data: InvoiceData;
  onBack: () => void;
  onDownload: () => void;
}

export default function InvoicePreview({ data, onBack, onDownload }: InvoicePreviewProps) {
  const calculateTotal = () => data.rate * data.units;

  return (
    <div id="invoice-preview" className="bg-white p-8 rounded-lg shadow-lg">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl font-bold">{data.companyName}</h1>
          <p className="text-gray-600">{data.companyAddress}</p>
          <p className="text-gray-600">PAN: {data.panNumber}</p>
          <p className="text-gray-600">GST: {data.gstNumber}</p>
        </div>
        <div className="text-right">
          <h2 className="text-xl font-bold">Training Invoice</h2>
          <p className="text-gray-600">Invoice No: {data.invoiceNumber}</p>
          <p className="text-gray-600">Date: {new Date().toLocaleDateString()}</p>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="font-semibold mb-2">Client Details:</h3>
        <p>{data.clientName}</p>
        <p>{data.clientAddress}</p>
        <p>{data.clientEmail}</p>
        <p>{data.clientPhone}</p>
      </div>

      <div className="mb-8">
        <h3 className="font-semibold mb-2">Trainer Details:</h3>
        <p>{data.trainerName}</p>
        <p>{data.trainerEmail}</p>
        <p>{data.trainerPhone}</p>
      </div>

      <div className="mb-8">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-2">Description</th>
              <th className="text-right py-2">Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="py-2">
                Training Services ({data.billingType}) -
                {data.units} {data.billingType === 'hourly' ? 'hours' : 
                  data.billingType === 'daily' ? 'days' : 'months'}
              </td>
              <td className="text-right py-2">₹{calculateTotal().toFixed(2)}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr className="border-t font-bold">
              <td className="py-2">Total</td>
              <td className="text-right py-2">₹{calculateTotal().toFixed(2)}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="mb-8">
        <p className="font-semibold">Amount in words:</p>
        <p className="capitalize">{numberToWords(calculateTotal())}</p>
      </div>

      <div className="mb-8">
        <h3 className="font-semibold mb-2">Bank Details:</h3>
        <p>Bank Name: {data.bankName}</p>
        <p>Bank Address: {data.bankAddress}</p>
        <p>Account Number: {data.accountNumber}</p>
        <p>IFSC Code: {data.ifscCode}</p>
      </div>

      <div className="flex justify-between items-center mt-16">
        <div>
          <p className="font-semibold">Authorized Signature</p>
          <div className="mt-8 border-t border-gray-400 w-48"></div>
        </div>
        <div className="space-x-4">
          <button
            onClick={onBack}
            className="bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Back to Edit
          </button>
          <button
            onClick={onDownload}
            className="flex items-center gap-2 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-5 h-5" />
            Download Invoice
          </button>
        </div>
      </div>
    </div>
  );
}